# Cap

Application Android (Capacitor) avec rappel quotidien discret. L’APK se compile tout seul sur GitHub, sans Android Studio.

## Obtenir l’APK
1. Crée un compte sur github.com, puis un nouveau dépôt **privé** (bouton « New »).
2. Envoie-y tout le contenu de ce dossier : `www/`, `package.json`, `capacitor.config.json`, `.gitignore`, `README.md` et le dossier **`.github/workflows/build-apk.yml`**.
   - Sur ordinateur : décompresse, puis glisse-dépose les fichiers dans « Add file > Upload files ».
   - Si le dossier `.github` (caché) ne part pas : « Add file > Create new file », nomme-le `.github/workflows/build-apk.yml` et colle le contenu du fichier.
3. Va dans l’onglet **Actions** : la compilation démarre seule (ou « Build APK > Run workflow »). Compte 5 à 8 minutes.
4. Ouvre l’exécution terminée, descends à **Artifacts**, télécharge **Cap-apk**, décompresse : tu obtiens `app-debug.apk`.
5. Sur ton téléphone Android, ouvre l’APK et autorise l’installation depuis cette source.

## Notifications
Dans l’appli, carte « Rappel du matin » : choisis l’heure, appuie sur Activer et accepte la permission. Le texte reçu est « Ton point du matin t’attend. », sans mention du sujet. Sur Android, désactive l’optimisation de batterie pour Cap si le rappel arrive en retard.

## Modifier l’appli
Tout le code est dans `www/index.html`. Chaque modification poussée sur GitHub recompile un nouvel APK.
